OC.L10N.register(
    "dailyverses",
    {
    "Daily Verses" : "Daily Verses",
    "Daily verses" : "Daily verses",
    "Toont een dagelijks Bijbelvers op het dashboard" : "Viser et dagligt bibelvers på instrumentbrættet",
    "Kan DailyVerses.net niet bereiken." : "Kan ikke få adgang til DailyVerses.net.",
    "Fout bij laden van DailyVerses.net." : "Fejl ved indlæsning af DailyVerses.net.",
    "Settings saved" : "Indstillinger gemt",
    "Error saving settings" : "Fejl ved gemning af indstillinger",
    "DailyVerses instellingen" : "DailyVerses indstillinger",
    "Persoonlijke instellingen toestaan" : "Tillad personlige indstillinger",
    "Taal" : "Sprog",
    "Bijbelvertaling" : "Biboversættelse",
    "Toon link naar DailyVerses.net" : "Vis link til DailyVerses.net",
    "Modus" : "Tilstand",
    "Verse of the Day" : "Dagens vers",
    "Random Verse" : "Tilfældig vers",
    "Opslaan" : "Gem",
    "Persoonlijke instellingen zijn uitgeschakeld." : "Personlige indstillinger er deaktiveret.",
    "De onderstaande instellingen worden beheerd door uw beheerder." : "De nedenstående indstillinger administreres af din administrator.",
    "Toon globale instellingen" : "Vis globale indstillinger"
},
"nplurals=2; plural=(n != 1);");
