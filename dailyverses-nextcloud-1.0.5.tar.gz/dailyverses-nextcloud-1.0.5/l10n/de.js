OC.L10N.register(
    "dailyverses",
    {
    "Daily Verses" : "Daily Verses",
    "Daily verses" : "Daily verses",
    "Toont een dagelijks Bijbelvers op het dashboard" : "Zeigt einen täglichen Bibelvers auf dem Dashboard",
    "Kan DailyVerses.net niet bereiken." : "Kann DailyVerses.net nicht erreichen.",
    "Fout bij laden van DailyVerses.net." : "Fehler beim Laden von DailyVerses.net.",
    "Settings saved" : "Einstellungen gespeichert",
    "Error saving settings" : "Fehler beim Speichern der Einstellungen",
    "DailyVerses instellingen" : "DailyVerses Einstellungen",
    "Persoonlijke instellingen toestaan" : "Persönliche Einstellungen zulassen",
    "Taal" : "Sprache",
    "Bijbelvertaling" : "Bibelübersetzung",
    "Toon link naar DailyVerses.net" : "Zeige den Link zu DailyVerses.net",
    "Modus" : "Modus",
    "Verse of the Day" : "Vers des Tages",
    "Random Verse" : "Zufälliger Vers",
    "Opslaan" : "Speichern",
    "Persoonlijke instellingen zijn uitgeschakeld." : "Persönliche Einstellungen sind deaktiviert.",
    "De onderstaande instellingen worden beheerd door uw beheerder." : "Die untenstehenden Einstellungen werden von Ihrem Administrator verwaltet.",
    "Toon globale instellingen" : "Globale Einstellungen anzeigen"
},
"nplurals=2; plural=(n != 1);");
